package application;

public class Fixed {
	public int cellId;
	
	public Fixed(int cellId) {
		this.cellId = cellId;
	}
}
